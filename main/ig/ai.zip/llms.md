# ans.fhir.fr.[code]#0.1.0: ANS IG Example

## Pages

* [Accueil](index.md)
* [Historique des versions](change-log.md)
* [Vue d'ensemble](sf1.md)
* [Flux 02](st_flux2.md)
* [Flux 01](st_flux1.md)
* [Artifacts Summary](artifacts.md)
* [Specifications Techniques](specifications_techniques.md)
* [Sécurité](securite.md)
* [Autres Ressources](autres_ressources.md)
* [Specifications Fonctionnelles](specifications_fonctionnelles.md)
* [Vue d'ensemble](construction_des_flux.md)
* [Téléchargements et usages](downloads.md)

## Resources

### CodeSystems

* [Compétences CodeSystem](CodeSystem-competence-code-system.md)
* [Type de carte](CodeSystem-type-carte-code-system.md)

### ValueSets

* [EyeColor Value Set](ValueSet-EyeColorVS.md)
* [Melting Pot Value Set](ValueSet-MeltingPotVS.md)
* [ModifiedAdministrativeGender](ValueSet-ModifiedAdministrativeGender.md)
* [Type Carte Value Set](ValueSet-TypeCarteVS.md)

### Resource Profiles

* [Patient français](StructureDefinition-fr-patient.md)

### Extensions

* [EyeColor](StructureDefinition-EyeColor.md)

### ImplementationGuides

* [ANS IG Example](index.md)

### Examples

* [frpatient-exemple (Patient)](Patient-frpatient-exemple.md)
